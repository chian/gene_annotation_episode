@echo off
REM
REM $Id: msvcvars.bat 683475 2024-05-29 14:53:50Z gouriano $
REM

:devenv

for /f "tokens=* USEBACKQ" %%i IN (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere" -version 17.0 -property productPath`) do (
    set DEVENV="%%i"
)

:end
